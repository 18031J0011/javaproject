package in.msitprogram.jntu.paypal;

import java.io.IOException;
import java.io.Serializable;

import in.msitprogram.jntu.paypal.console.MainMenu;

/**
 * @author pg
 *
 */
public class PPSystem implements Serializable
{

	public static void main(String[] args) throws IOException, ClassNotFoundException 
	{
		MainMenu.show();
	}

}
