package in.msitprogram.jntu.paypal.console;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.persistance.DataStore;
import in.msitprogram.jntu.paypal.utils.PPToolkit;

import java.io.IOException;
import java.util.Scanner;

public class PPAccountActivationScreen {
	
	public static void show() throws IOException, ClassNotFoundException {
		PPAccount account = null;
		String email = ""; 					//change to get console input
		System.out.println(" 1. Suspending \n 2. Activating\n");
		Scanner sc = new Scanner(System.in);
		int ch=sc.nextInt();
		switch(ch)
		{
			case 1: System.out.println("Enter Email");
					email=sc.next();
			try
			{
				account = DataStore.lookupAccount(email);
				System.out.println("PPAccountActivationScreen"+account);
			}
			catch(Exception e)
			{
			}
			if(account!=null)
				{
					if(account.isActivated())
					{
						account.setActivated(false);
						DataStore.writeAccount(account);
						System.out.println("account is suspended");
						MainMenu.show();
					}
				}
				else
				{
					System.out.println(" account doesnt exists ");
					MainMenu.show();
				}
						
			
        
			case 2:System.out.println("Enter Email");
					email=sc.next();
					try
					{
						account = DataStore.lookupAccount(email);
					}
					catch(Exception e)
					{
					}
					
					if(account!=null)
						{
							if(!account.isActivated())
							{
								String s=account.getActivationCode();
								System.out.println("Enter your activation code");
								String s1=sc.next();
								if(s1.equals(s))
								{
									account.setActivated(true);
									System.out.println(" account is activated");
									DataStore.writeAccount(account);
									System.out.println(account);
									MainMenu.show();
								}
							}
						}
						else
						{
							System.out.println("account doesnt exists ");
						}
					} 
			
					
					
		}
	}

		/*
		 * TODO
		 * fetch the account object using email address
		 * check if the account is suspended
		 * if suspended then activate it
		 * if activation code invalid, retry for 2 more attempts
		 * on successful activation show main menu
		 * on failure show the error message and continue to main menu
		 */				
		//System.out.println("hello world");
		//PPAccount account = DataStore.lookupAccount(email);
		
		//check if account is active. if yes then ask for suspending it
		
		// if yes suspend it if not go back to main menu
		
		// accept activation code, check if valid, if not give 2 more attempts
		
		//proceed to main menu
		//MainMenu.show();
	
	
