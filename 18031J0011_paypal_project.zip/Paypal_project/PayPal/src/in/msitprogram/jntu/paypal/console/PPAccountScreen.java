package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Formattable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.accounts.PPRestrictedAccount;
import in.msitprogram.jntu.paypal.accounts.Transaction;
import in.msitprogram.jntu.paypal.persistance.DataStore;

public class PPAccountScreen {
	PPAccount account;
	Scanner scan;
	
	public PPAccountScreen(String email) throws ClassNotFoundException, IOException {
		scan = new Scanner(System.in);
		account = DataStore.lookupAccount(email);
		//System.out.println(account);
	}

	public void show() throws IOException, ClassNotFoundException {
		
		//check if account is active
		if(account.isActivated())
		{
			System.out.println(account);
			System.out.println("1.Deposit\n 2.Withdraw\n 3.Request Money\n 4.Send Money\n");
			System.out.println("enter your choice");
			Scanner sc=new Scanner(System.in);
			int ch=sc.nextInt();
			switch(ch)
			{
				case 1:addFunds();
						DataStore.writeAccount(account);
						MainMenu.show();
						break;
				case 2:withdrawFunds() ;
						DataStore.writeAccount(account);
						MainMenu.show();
						break;
				case 3:	requestMoney();
						DataStore.writeAccount(account);
						MainMenu.show();
						break;
				case 4:sendMoney();
						DataStore.writeAccount(account);
						MainMenu.show();
						break;
						
						
			}
			
		}
		else 
		{
			System.out.println("activate your account");
		}
		
				
			}
		
		//if active
		
			// print the account summary
	//		System.out.println(account);
			
			// print menu and accept menu options
			// for all the paypal account operations
			
		
	

	private void withdrawFunds() throws IOException, ClassNotFoundException 
	{
		if(account instanceof PPRestrictedAccount)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("enter amount to withdraw");
			float withdraw=sc.nextFloat();
			float bal=account.getAccountBal();
			if(withdraw>4000)
			{
				System.out.println("limited crossed");
			}
			else
			{
				if(bal>withdraw)
				{
					account.setAccountBal(account.getAccountBal()-withdraw);
				}
				else
				{
					System.out.println("insufficient balance");
					MainMenu.show();
				}
			}
			DataStore.writeAccount(account);
			System.out.println("present balance"+account.getAccountBal());
		}
		else
		{
		boolean y=true;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter amount to withdraw");
		float withdraw=sc.nextFloat();
		float bal=account.getAccountBal();
		if(bal>withdraw)
		{
			bal=bal-withdraw;
		
		}
		else
		{
			System.out.println("insufficient");
			MainMenu.show();
		}
		account.setAccountBal(account.getAccountBal()+withdraw);
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		String tDate = formatter.format(date);
		 Date date1 = Calendar.getInstance().getTime();  
	     DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");  
	     String tTime = dateFormat.format(date1);  
	     String reference =account.getActivationCode();
	    		 
		String narration="debit";
		String status;
		if(y==true)
		{
		 status=" the amount is debited";
		}
		else
		{
		 status="not debited";
		}
		float credit1=0;
		 float debit=withdraw;
		Transaction t = new Transaction(tTime,tDate,account,narration,reference,status,debit,withdraw);
		account.setTransactions(t);
		
		DataStore.writeAccount(account);
		System.out.println("present bal"+bal);
		//account=new PPAccount();
		//account =new PPAccount();

		//account.setTransactions(ArrayList<Transaction>);
		
		//account.setTransactions(date);
		//System.out.println(date); 
		
		}

	}
		// implement the withdraw funds user interface here
		
		//use the account object as needed for withdraw funds
		
	

	private void requestMoney() throws ClassNotFoundException, IOException 
	{
		boolean y=true;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a email to  request money");
		String email1=sc.next();
		PPAccount account2 = null;
		account2=DataStore.lookupAccount(email1);
		System.out.println("enter how much money you want to request");
		float request=sc.nextFloat();
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		String tDate = formatter.format(date);
		 Date date1 = Calendar.getInstance().getTime();  
	     DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");  
	     String tTime = dateFormat.format(date1);  
	     String reference1=account.getEmail1();
	     String reference=account2.getEmail1();		 
		String narration="debit";
		String status;
		if(y==true)
		{
		 status=" the amount is debited";
		}
		else
		{
		 status="not debited";
		}
		float credit1=request;
		 float debit=0;
		Transaction t = new Transaction(tTime,tDate,account,narration,reference,status,debit,request);
		account.setTransactions(t);
		float credit=0;
		float debit1=credit1;
		Transaction t1=new Transaction(tTime,tDate,account2,narration,reference1,status,debit1,credit);
		account.setTransactions(t1);
		DataStore.writeAccount(account2);
		DataStore.writeAccount(account);
		System.out.println(t.toString());
		System.out.println(t1.toString());
		//account2.addFunds(request);
		//account2.addFunds(request);
		
		
		
		
		// 	implement the request money user interface here
		
		//use the account object as needed for request money funds
	}

	private void sendMoney() throws ClassNotFoundException, IOException 
	{
		boolean y=true;
		Scanner sc=new Scanner(System.in);
		PPAccount account1=null;
		System.out.println("enter email to send money");
		String email1=sc.next();
		account1=DataStore.lookupAccount(email1);
		System.out.println("enter how much money to send");
		float send=sc.nextFloat();
		float credit1=account1.getAccountBal();
		
		float bal=credit1-send;
		account1.setAccountBal(bal);
		float bal1=account.getAccountBal();
		float credit2=bal1+send;
		account.setAccountBal(credit2);
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		String tDate = formatter.format(date);
		 Date date1 = Calendar.getInstance().getTime();  
	     DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");  
	     String tTime = dateFormat.format(date1);  
	     String reference1=account.getEmail1();
	     String reference=account1.getEmail1();		 
		String narration="debit";
		
		String status;
		if(y==true)
		{
		 status=" the amount is debited";
		}
		else
		{
		 status="not debited";
		}
		float credit=0 ;
		 float debit=send;
		 Transaction t = new Transaction(tTime,tDate,account,narration,reference1,status,debit,credit);
		account.setTransactions(t);
		String narration1="credit";
		
		String status1;
		if(y==true)
		{
		 status1=" the amount is credited";
		}
		else
		{
		 status1="not debited";
		}
		float credit3=credit1;
		float debit1=send;
		Transaction t1=new Transaction(tTime,tDate,account1,narration1,reference,status1,debit1,credit3);
		account.setTransactions(t1);
		DataStore.writeAccount(account);
		DataStore.writeAccount(account1);
		System.out.println(t.toString());
		System.out.println(t1.toString());
		
		
		// implement the send moeny user interface here
		
		//use the account object as needed for send money funds
	}

	private void addFunds() throws IOException, ClassNotFoundException
	{
		if(account instanceof PPRestrictedAccount)
		{
			System.out.println("not available to debit:");
		}
		else
		{
			
		
		boolean y=true;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter amount to add");
	float credit=sc.nextFloat();
	float bal=account.getAccountBal();
	bal=bal+credit;
	account.setAccountBal(account.getAccountBal()+credit);
	Date date = new Date();
	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
	String tDate = formatter.format(date);
	 Date date1 = Calendar.getInstance().getTime();  
     DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");  
     String tTime = dateFormat.format(date1);  
     String reference =account.getActivationCode();
    		 
	String narration="credit";
	String status;
	if(y==true)
	{
	 status=" the amount is credited";
	}
	else
	{
	 status="not debited";
	}
	float credit1=credit;
	 float debit=0;
	Transaction t = new Transaction(tTime,tDate,account,narration,reference,status,debit,credit);
	account.setTransactions(t);
	
	DataStore.writeAccount(account);
	System.out.println(t.toString());
	System.out.println("present bal"+bal);
		}
	
	// implement the add funds user interface here
		
		//use the account object as needed for add funds
	}

}