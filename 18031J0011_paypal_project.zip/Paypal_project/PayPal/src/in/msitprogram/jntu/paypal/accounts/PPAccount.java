package in.msitprogram.jntu.paypal.accounts;

import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.console.PPAccountActivationScreen;

public class PPAccount implements Serializable
{
	/**
	 * 
	 */
	private Profile profile;
	private String email;
	private float accountBal;
	private boolean isActivated;
	private String activationCode;
	private ArrayList<Transaction> transactions;
	
	public PPAccount()
	{
		
	}
	public PPAccount(Profile profile, String email) 
	{
		this.profile=profile;
		this.email=email;
		
		// TODO Auto-generated constructor stub
	}

	/*public String toString()
	{
		// implement this function to return a beautiful looking string
		// to display the summary of the account
		return ;
	}*/

	public void activate(String activationCode) 
	{
		
		// TODO Auto-generated method stub
		
	}
	
	public void suspend() 
	{
		// TODO Auto-generated method stub
		boolean isActivated=true;
	}


	public boolean withdraw(float withdrawAmount)
	{
		this.accountBal=this.accountBal-withdrawAmount;
		return false;
	}


	public boolean addFunds(float creditAmount) 
	{
		

		this.accountBal=this.accountBal+creditAmount;
		return false;
	}
	
	public boolean sendMoney(float creditAmount) 
	{
		
		return false;
	}
	
	public boolean requestMoney(float creditAmount) 
	{
		
		return false;
	}

	public Object getEmail() {
		// TODO Auto-generated method stub
		return email;
	}
	public String getEmail1() 
	{
		// TODO Auto-generated method stub
		return email;
	}
	

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

	public float getAccountBal() 
	{
		return accountBal;
	}

	public void setAccountBal(float accountBal) {
		this.accountBal = accountBal;
	}

	public boolean isActivated() {
		return isActivated;
	}

	public void setActivated(boolean isActivated) {
		this.isActivated = isActivated;
	}

	public String getActivationCode() {
		return activationCode;
	}

	public void setActivationCode(String activationCode) throws IOException, ClassNotFoundException
	{
		this.activationCode= activationCode;
	}

	public ArrayList<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(ArrayList<Transaction> transactions)
	{
		
		this.transactions = transactions;
		
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "PPAccount [profile=" + profile + ", email=" + email + ", accountBal=" + accountBal + ", isActivated="
				+ isActivated + ", activationCode=" + activationCode + "]";
	}
	public void setTransactions(Transaction t) 
	{
		// TODO Auto-generated method stub
		this.transactions = transactions;
		
	}
	
	
}
