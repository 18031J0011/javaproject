/**
 * 
 */
package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;

/**
 * @author pg
 *
 */
public class MainMenu implements Serializable {
	
	public static void show() throws IOException, ClassNotFoundException
	{
		Scanner sc=new Scanner(System.in);
		int ch;
		
		String email;
		System.out.println("Welcome to paypal");
		//show the welcome message with the main menu options
		System.out.println("\nMain menu:\n1.create paypal account\n 2.signin");
		System.out.println("enter your chioce");
		ch=sc.nextInt();
		if(ch==1)
		{
			System.out.println("enter your email");
			email=sc.next();
			PPNewAccountScreen p=new PPNewAccountScreen(email);
			p.show();
		}
		if(ch==2)
		{
			System.out.println("enter your email");
			email=sc.next();
			PPAccountScreen p=new PPAccountScreen(email);
			p.show();
		}
		
		
		//take the menu option as input from the console
		
		//take email address as input from the console
		
		//based on the given menu option instantiate the respective screens
	}

}
