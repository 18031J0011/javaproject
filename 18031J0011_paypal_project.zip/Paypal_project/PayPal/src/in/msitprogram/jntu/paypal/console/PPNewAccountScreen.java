package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.accounts.PPBusinessAccount;
import in.msitprogram.jntu.paypal.accounts.PPRestrictedAccount;
import in.msitprogram.jntu.paypal.accounts.Profile;
import in.msitprogram.jntu.paypal.persistance.DataStore;
import in.msitprogram.jntu.paypal.utils.PPToolkit;

public class PPNewAccountScreen implements Serializable {
	Profile profile;
	PPAccount account;
	String email;
	Scanner scan;
	String activationcode;
	PPRestrictedAccount account1;
	//Scanner sc=new Scanner(System.in);
	public PPNewAccountScreen(String email) 
	{
		profile = new Profile(email, email, email);
		scan = new Scanner(System.in);
		this.email = email;
	}

	public void show() throws IOException, ClassNotFoundException {
		//check if the account with the given email address exists 
		
		int ch;
		profile=createProfile();
		System.out.println(profile.getName());
		System.out.println(profile.getAddress());
		System.out.println(profile.getPhone());
		//System.out.println("enter your email:");
		System.out.println("\n1.createBusinessAccount\n 2.createStudentAccount\n 3.createPersonalAccount\n");
		System.out.println("enter your chioce");
		ch=scan.nextInt();
		switch(ch)
			{
				case 1:	createBusinessAccount();
						break;
				case 2:	createStudentAccount();
						break;
				case 3:	createPersonalAccount();
						break;
				default :break;
			}
		
		//if not create the user profile
		
		//show the account types
		
		//based on the given account type selected create the account object
	}

	private Profile createProfile()
	{
		// use this for creating the profile
		System.out.println("enter name,address,phone number");
		String s=scan.next();
		String s1=scan.next();
		String s2=scan.next();
		
		profile.setName(s);
		profile.setAddress(s1);
		profile.setPhone(s2);
		profile=new Profile(s,s1,s2);
		return profile;
	}

	private void createBusinessAccount() throws IOException {
		//use this for creating the business account
	}
	private void createStudentAccount() throws IOException, ClassNotFoundException
	{
		//use this for creating the student account 
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter parent Email");
		String parentemail=sc.next();
		account =DataStore.lookupAccount(parentemail);
		if(account==null)
		{
			System.out.println("Invalid parent Email");
		}
		else
		{
			account1=new PPRestrictedAccount(profile,email);
			account1.setParentEmail(account.getEmail());
			account1.setWithdrawLimit(4000);
			account1.setActivated(false);
			account1.addFunds(1000);
			account=account1;
			completeAccountCreation();
			
		}
	}

	/*
	 * this method create the personal account, saves it to the file system
	 * and redirects the users to the next screen
	 */
	private void createPersonalAccount() throws IOException, ClassNotFoundException 
	{
		account=new PPAccount(profile,email);
		account.setEmail(email);
		account.setAccountBal(0.0f);
		account.setActivated(false);
		account.addFunds(0);
		completeAccountCreation();
		
		
		//datastore.lookupAccount(account);
		//use this for creating the personal account
		
	}
	
	private void completeAccountCreation() throws IOException, ClassNotFoundException
	{
		Scanner sc = new Scanner(System.in);
		String s=PPToolkit.generateActivationCode();
		account.setActivationCode(s);
		DataStore.writeAccount(account);
		System.out.println("Your account activation code is"+s);
		System.out.println("1.Activation Screen 2.MainMenu");
		int g=sc.nextInt();
		switch(g)
		{
		case 1:PPAccountActivationScreen ppaas=new PPAccountActivationScreen();
		       ppaas.show();
		       break;
		case 2:MainMenu.show();
		       break;
		}
		//send activation code to the phone
		
		//ask & redirect the user to the activation screen or the main menu
		
	}

}
